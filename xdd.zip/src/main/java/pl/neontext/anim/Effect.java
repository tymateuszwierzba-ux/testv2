package pl.neontext.anim;

import java.util.Locale;

/**
 * Every animation NeonText can apply to a piece of text.
 * <p>
 * An effect is a pure function of {@code (characterIndex, characterCount, time)} - it never
 * touches rendering itself. The renderer asks the effect for a {@link GlyphStyle} per glyph and
 * then draws. That split is what makes the whole system reusable across nameplates, the tab
 * list, chat and world holograms.
 */
public enum Effect {

    /** Vanilla look - no animation at all. Always available as an escape hatch. */
    NONE("None", "Static text"),

    /** Full spectrum hue rotation, offset per character. */
    RAINBOW("Rainbow", "Classic RGB cycle"),

    /** Two or more colours blended smoothly across the whole string. */
    GRADIENT("Gradient", "Smooth colour blend"),

    /** A bright band travelling through the text. */
    WAVE("Wave", "Colour wave sweep"),

    /** Characters bob up and down one after another. */
    BOUNCE("Bounce", "Jumping letters"),

    /** Whole string breathes in and out. */
    PULSE("Pulse", "Scaling heartbeat"),

    /** Text flickers like a broken neon sign. */
    FLICKER("Flicker", "Neon sign flicker"),

    /** RGB split + random jitter, cyberpunk style. */
    GLITCH("Glitch", "Datamosh shake"),

    /** Soft sinusoidal sway, left to right. */
    SLIDE("Slide", "Side to side sway"),

    /** Per character spin in the Z axis. */
    SPIN("Spin", "Rotating glyphs"),

    /** Letters fade in and out in sequence. */
    FADE("Fade", "Ghosting letters"),

    /** Colours jump between palette entries with no blending. */
    STROBE("Strobe", "Hard colour cuts"),

    /** Per character random colour noise, TV static. */
    STATIC("Static", "Colour noise"),

    /** Text burns with a vertical heat gradient that licks upwards. */
    FIRE("Fire", "Burning text"),

    /** Cold blue/cyan gradient with a slow shimmer. */
    ICE("Ice", "Frozen shimmer"),

    /** Gold gradient with a travelling specular highlight. */
    GOLD("Gold", "Shiny bullion"),

    /** Green terminal phosphor with scanline flicker. */
    MATRIX("Matrix", "Terminal phosphor"),

    /** Pink/purple vaporwave gradient with heavy glow. */
    VAPOR("Vaporwave", "A E S T H E T I C"),

    /** White hot core with a coloured halo, per character. */
    GLOW("Glow", "Neon tube"),

    /** Rainbow that also bounces - the "flex" preset. */
    RAINBOW_BOUNCE("Rainbow Bounce", "Colour + movement"),

    /** Letters rise continuously like bubbles. */
    BUBBLE("Bubble", "Rising letters"),

    /** Text scrambles through random glyphs, then settles. */
    SCRAMBLE("Scramble", "Decoding text"),

    /** Slow heartbeat thump with a red flash. */
    HEARTBEAT("Heartbeat", "Thump thump"),

    /** Alternating per character colour from the palette, marching. */
    CANDY("Candy", "Striped sweets"),

    /** Inverted / negative colours pulsing. */
    INVERT("Invert", "Negative pulse"),

    /** Text wobbles like jelly. */
    JELLY("Jelly", "Squash and stretch"),

    /** Lightning white-blue flashes at random intervals. */
    LIGHTNING("Lightning", "Storm flashes"),

    /** Slow, calm hue drift - the "subtle" preset. */
    AURORA("Aurora", "Calm northern lights");

    private final String displayName;
    private final String description;

    Effect(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String displayName() {
        return displayName;
    }

    public String description() {
        return description;
    }

    /** Lowercase id used in the JSON config, e.g. {@code RAINBOW_BOUNCE -> "rainbow_bounce"}. */
    public String id() {
        return name().toLowerCase(Locale.ROOT);
    }

    public static Effect fromId(String id) {
        if (id == null) {
            return NONE;
        }
        try {
            return Effect.valueOf(id.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            return NONE;
        }
    }

    public Effect next() {
        Effect[] all = values();
        return all[(ordinal() + 1) % all.length];
    }

    public Effect prev() {
        Effect[] all = values();
        return all[(ordinal() - 1 + all.length) % all.length];
    }
}
